package com.stellarapps.kotlinapp

class Person constructor(firstname : String = "Akhil", lastname : String = "Attri"){
    var hobby = "default"
    var firstname : String?= null
    init{
        this.firstname = firstname
        println("Person '$firstname $lastname' has been initiated")
    }
    fun hashobby(){
        println("${this.firstname} likes $hobby")
    }
}
fun addupvals( val1 : Int, val2 : Int): Int{
    return val1+val2
}

fun main(){
    println("hello world")
    var p1 = Person()
    p1.hobby = "learning"
    p1.hashobby()
    println("Sum is ${addupvals(5,3)}")
}
