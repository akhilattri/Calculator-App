package com.stellarapps.kotlinapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val displayres = findViewById<TextView>(R.id.resulttext)

        val addition = findViewById<Button>(R.id.addbutton)
        val subtraction = findViewById<Button>(R.id.subbutton)
        val multiplication = findViewById<Button>(R.id.mulbutton)
        val division = findViewById<Button>(R.id.divbutton)

        addition.setOnClickListener{
            val fnum = findViewById<EditText>(R.id.num1).text.toString().toDouble()
            val snum = findViewById<EditText>(R.id.num2).text.toString().toDouble()

            var result  = fnum + snum
            displayres.text = "Result : " + result
            Toast.makeText(this@MainActivity, "Addition performed!", Toast.LENGTH_SHORT).show()
        }
        subtraction.setOnClickListener{
            val fnum = findViewById<EditText>(R.id.num1).text.toString().toDouble()
            val snum = findViewById<EditText>(R.id.num2).text.toString().toDouble()

            var result  = fnum - snum
            displayres.text = "Result : " + result
            Toast.makeText(this@MainActivity, "Subtraction performed!", Toast.LENGTH_SHORT).show()
        }
        multiplication.setOnClickListener{
            val fnum = findViewById<EditText>(R.id.num1).text.toString().toDouble()
            val snum = findViewById<EditText>(R.id.num2).text.toString().toDouble()

            var result  = fnum * snum
            displayres.text = "Result : " + result
            Toast.makeText(this@MainActivity, "Multiplication performed!", Toast.LENGTH_SHORT).show()
        }
        division.setOnClickListener{
            val fnum = findViewById<EditText>(R.id.num1).text.toString().toDouble()
            val snum = findViewById<EditText>(R.id.num2).text.toString().toDouble()
            if(snum==0.0) {
                displayres.text = "Invalid Operation!"
                Toast.makeText(this@MainActivity, "Can't comprehend infinity, yet ;)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            var result  = fnum / snum
            displayres.text = "Result : " + result
            Toast.makeText(this@MainActivity, "Division performed!", Toast.LENGTH_SHORT).show()
        }
    }
}